package com.inc.ocapop.objects;

public class ContatoUser {

    private String celular;

    public ContatoUser(String celular) {
        this.celular = celular;
    }

    public ContatoUser() {
    }

    public String getCelular() {
        return celular;
    }

}
