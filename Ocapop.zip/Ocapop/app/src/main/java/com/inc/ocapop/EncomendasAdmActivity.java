package com.inc.ocapop;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class EncomendasAdmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encomendas_adm);
    }
}
